var unicorn, unicorn_running;
var ground, invisibleGround;

var cloudsGroup, cloudImage;
var treesGroup, tree1;

var score;
var GameOverImg,restartImg
var highScore=0;

var PLAY=1;
var END=0;
var gameState=PLAY;

function preload(){
  unicorn_running = loadImage("koala-removebg-preview.png");
 
  
  groundImage = loadImage("desert_ground.png");
  
  cloudImage = loadImage("clouds2.png");
  
  
   tree1 = loadImage("bamboo-tree-png-40469-free-icons-and-png-backgrounds-bamboo-tree-png-646_900.png");
 
  


  
  restartImg = loadImage("restart_icon.png")
  GameOverImg = loadImage("GameOver.png")
  

}

function setup() {
  createCanvas(600, 200);

 
  
  
  unicorn = createSprite(50,160,20,50);
  unicorn.addImage("running", unicorn_running);
  unicorn.scale=0.25



  
  
  ground = createSprite(0,0,600,200);
  ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  
  GameOver = createSprite(300,100);
  GameOver.addImage(GameOverImg);
  GameOver.scale=0.3
  
  restart = createSprite(300,140);
  restart.addImage(restartImg);
  restart.scale=0.15
  
 
  
  
  invisibleGround = createSprite(200,200,365,60);
  invisibleGround.visible = false;
  
  //create Obstacle and Cloud Groups
  treesGroup = new Group();
  cloudsGroup = new Group();

  
  unicorn.setCollider("circle",0,0,40);
  //unicorn.debug = true
  
  score = 0;
  
}

function draw() {
  
  background(180);
  //displaying score
  text("Score: "+ score, 500,50);
  text("High  Score:  "+highScore,390,50);
  
  
  if(gameState === PLAY){
    

    GameOver.visible = false;
    restart.visible = false;
    //unicorn.changeImage("running",unicorn_running)
    
    
    
    
    
    
    ground.velocityX = -(4 + 3* score/100)
    //scoring
    score = score + Math.round(getFrameRate()/60);
    

    
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
    
    //jump when the space key is pressed
    if(keyDown("space")&& unicorn.y >= 100) {
        unicorn.velocityY = -12;
        
    }
    
    //add gravity
    unicorn.velocityY = unicorn.velocityY + 0.8
  
    //spawn the clouds
    spawnClouds();
  
    //spawn obstacles on the ground
    spawnTrees();
    
    if(treesGroup.isTouching(unicorn)){
        //trex.velocityY = -12;
        gameState = END;
       
    }
  }
    
  
   else if (gameState === END){
      GameOver.visible = true;
      restart.visible = true;
     if(mousePressedOver(restart)) {
      reset();
    }
     if  (highScore<score){
       highScore=score;
     }
     
     //change the trex animation
     //unicorn.changeAnimation("collided", unicorn_collided);
  
     
     
      ground.velocityX = 0;
      unicorn.velocityY = 0
    
     
      //set lifetime of the game objects so that they are never destroyed
    treesGroup.setLifetimeEach(-1);
    cloudsGroup.setLifetimeEach(-1);
     
     treesGroup.setVelocityXEach(0);
     cloudsGroup.setVelocityXEach(0);    
   }
  
 
  //stop trex from falling down
  unicorn.collide(invisibleGround);
  
  drawSprites();
}


 


function reset(){
  gameState=PLAY;
  treesGroup.destroyEach();
  cloudsGroup.destroyEach();
  score=0
  
  
  
  
  
  
  
  
  
  
}


function spawnTrees(){
 if (frameCount % 60 === 0){
   var tree = createSprite(600,175,10,40);
   tree.velocityX = -(6 + score/100);
   
   
    //generate random obstacles
    /*var rand = Math.round(random(1,6));
    switch(rand) {
      case 1: tree.addImage(tree1);
              break;

    
      default: break;
    }*/
   tree.addImage(tree1)

   
    //assign scale and lifetime to the obstacle           
    tree.scale = 0.1;
    tree.lifetime = 300;
   
   //add each obstacle to the group
    treesGroup.add(tree);
 }
}

function spawnClouds() {
  //write code here to spawn the clouds
  if (frameCount % 60 === 0) {
    var cloud = createSprite(600,80,40,10);
    cloud.y = Math.round(random(40,80));
    cloud.addImage(cloudImage);
    cloud.scale = 0.1;
    cloud.velocityX = -3;
    
    
    
     //assign lifetime to the variable
    cloud.lifetime = 180;
    
    //adjust the depth
    cloud.depth = unicorn.depth;
    unicorn.depth = unicorn.depth + 1;
    
    //add each cloud to the group
    cloudsGroup.add(cloud);
  }
}
